package banco;

public interface Conversor {
	public abstract double convertir();
}
