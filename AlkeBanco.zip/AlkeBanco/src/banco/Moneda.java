package banco;

public enum Moneda {
	CLP,
	USD,
	EUR,
	YEN,
	WON
}
