
public class Efectivo extends FormaDePago{

	public Efectivo() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void realizarPago() {
		System.out.println("Estoy pagando en efectivo KACHING!");
	}
	
	
}
