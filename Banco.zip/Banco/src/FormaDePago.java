
public abstract class FormaDePago {

	public FormaDePago() {
		super();
	}
	
	public abstract void realizarPago();
}
