
public class TarjetaDeCredito extends FormaDePago{

	public TarjetaDeCredito() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void realizarPago() {
		System.out.println("Estoy pagando con tarjeta de credito a 3 cuotas sin interes.");
	}

	
	
}
