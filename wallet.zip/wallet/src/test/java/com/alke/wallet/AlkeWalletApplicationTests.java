package com.alke.wallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlkeWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
